@extends('layouts.app')

@section('title', 'Tambah Portfolio')
@section('page-title', 'Tambah Portfolio')
@section('page-subtitle', 'Unggah karya Anda untuk ditampilkan di profil toko')

@section('sidebar-nav')
    <a href="{{ route('tailor.dashboard') }}"
       class="nav-link {{ request()->routeIs('tailor.dashboard*') ? 'active' : '' }}">
        <svg class="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                  d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
        </svg>
        Dashboard
    </a>
    <a href="{{ route('tailor.profile.edit') }}"
       class="nav-link {{ request()->routeIs('tailor.profile*') ? 'active' : '' }}">
        <svg class="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                  d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
        </svg>
        Profil Toko
    </a>
    <a href="{{ route('tailor.portfolios.index') }}"
       class="nav-link {{ request()->routeIs('tailor.portfolios*') ? 'active' : '' }}">
        <svg class="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                  d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
        </svg>
        Portfolio
    </a>
    <a href="{{ route('tailor.orders.index') }}"
       class="nav-link {{ request()->routeIs('tailor.orders*') ? 'active' : '' }}">
        <svg class="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                  d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"/>
        </svg>
        Pesanan Masuk
    </a>
@endsection

@section('content')
<div class="mx-auto max-w-3xl space-y-6">

    <section class="overflow-hidden rounded-[2rem] border border-tailor-purple/10 bg-white shadow-soft">
        <div class="relative brand-gradient p-5 text-white sm:p-7">
            <div class="absolute inset-y-0 right-0 hidden w-1/3 bg-[radial-gradient(circle_at_top_right,rgba(240,179,79,0.35),transparent_55%)] sm:block"></div>
            <div class="relative flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
                <div>
                    <p class="text-xs font-black uppercase tracking-[0.24em] text-tailor-gold">Tambah Portfolio</p>
                    <h1 class="mt-2 text-2xl font-black tracking-tight sm:text-3xl">Unggah karya baru</h1>
                    <p class="mt-2 max-w-2xl text-sm font-medium leading-6 text-white/75">
                        Gunakan foto yang jelas, judul spesifik, dan kategori yang tepat agar customer cepat memahami kualitas karya Anda.
                    </p>
                </div>
                <button type="submit" form="portfolioCreateForm"
                        class="inline-flex items-center justify-center rounded-2xl bg-white px-5 py-3 text-sm font-extrabold text-tailor-purple shadow-sm transition hover:bg-tailor-cream">
                    Simpan Portfolio
                </button>
            </div>
        </div>
    </section>

    @if($errors->any())
        <div class="bg-red-50 border border-red-200 text-red-800 px-4 py-3.5 rounded-xl mb-6">
            <div class="flex items-center gap-2 mb-2">
                <svg class="w-5 h-5 text-red-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                </svg>
                <span class="text-sm font-semibold">Mohon perbaiki kesalahan berikut:</span>
            </div>
            <ul class="list-disc list-inside space-y-1">
                @foreach($errors->all() as $error)
                    <li class="text-sm">{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="bg-white rounded-2xl shadow-soft border border-tailor-purple/10 overflow-hidden">
        <div class="px-6 py-4 border-b border-slate-100 flex items-center gap-3">
            <div class="w-8 h-8 bg-tailor-soft rounded-lg flex items-center justify-center">
                <svg class="w-4 h-4 text-tailor-purple" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                </svg>
            </div>
            <div>
                <h2 class="text-base font-semibold text-slate-800">Informasi Portfolio</h2>
                <p class="text-xs text-slate-500 mt-0.5">Isi detail karya yang ingin Anda tampilkan</p>
            </div>
        </div>

        <form id="portfolioCreateForm" action="{{ route('tailor.portfolios.store') }}" method="POST" enctype="multipart/form-data" class="p-6 space-y-5">
            @csrf

            {{-- Image Upload --}}
            <div>
                <label class="block text-sm font-medium text-slate-700 mb-2">
                    Gambar Portfolio <span class="text-red-500">*</span>
                </label>

                {{-- Drop Zone --}}
                <div id="image-dropzone"
                     onclick="document.getElementById('image').click()"
                     ondragover="handleDragOver(event)"
                     ondragleave="handleDragLeave(event)"
                     ondrop="handleDrop(event)"
                     class="relative border-2 border-dashed border-slate-200 rounded-xl overflow-hidden cursor-pointer hover:border-tailor-purple/40 hover:bg-tailor-soft/30 transition-all group">

                    {{-- Preview (hidden by default) --}}
                    <div id="image-preview-container" class="hidden">
                        <img id="image-preview" src="" alt="Preview" class="w-full max-h-72 object-contain bg-slate-50">
                        <div class="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                            <div class="opacity-0 group-hover:opacity-100 transition-opacity bg-white/90 backdrop-blur-sm px-3 py-2 rounded-lg text-xs font-medium text-slate-700 flex items-center gap-1.5">
                                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"/>
                                </svg>
                                Ganti Gambar
                            </div>
                        </div>
                    </div>

                    {{-- Placeholder --}}
                    <div id="image-placeholder" class="flex flex-col items-center justify-center py-12 px-6 text-center">
                        <div class="w-14 h-14 bg-tailor-soft rounded-xl flex items-center justify-center mb-3 group-hover:bg-tailor-soft transition-colors">
                            <svg class="w-7 h-7 text-tailor-purple/55" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"/>
                            </svg>
                        </div>
                        <p class="text-sm font-medium text-slate-600">Klik atau seret gambar ke sini</p>
                        <p class="text-xs text-slate-400 mt-1">JPG, PNG, WebP - Maks. 5MB</p>
                    </div>
                </div>

                <input type="file" id="image" name="image" accept="image/*" class="hidden" required>
                @error('image')
                    <p class="text-xs text-red-500 mt-1.5">{{ $message }}</p>
                @enderror
            </div>

            {{-- Title --}}
            <div>
                <label for="title" class="block text-sm font-medium text-slate-700 mb-1.5">
                    Judul Portfolio <span class="text-red-500">*</span>
                </label>
                <input type="text" id="title" name="title"
                       value="{{ old('title') }}"
                       placeholder="Contoh: Kebaya Modern Pengantin 2024"
                       class="w-full px-4 py-2.5 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-tailor-gold focus:border-transparent @error('title') border-red-300 focus:ring-red-500 @enderror">
                @error('title')
                    <p class="text-xs text-red-500 mt-1">{{ $message }}</p>
                @enderror
            </div>

            {{-- Category --}}
            <div>
                <label for="category" class="block text-sm font-medium text-slate-700 mb-1.5">
                    Kategori
                </label>
                <select id="category" name="category"
                        class="w-full px-4 py-2.5 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-tailor-gold focus:border-transparent @error('category') border-red-300 focus:ring-red-500 @enderror">
                    <option value="">-- Pilih Kategori --</option>
                    @foreach($categoryOptions as $cat)
                        <option value="{{ $cat }}" {{ old('category') === $cat ? 'selected' : '' }}>{{ $cat }}</option>
                    @endforeach
                </select>
                @error('category')
                    <p class="text-xs text-red-500 mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label for="client_type" class="block text-sm font-medium text-slate-700 mb-1.5">
                        Tipe Proyek
                    </label>
                    <select id="client_type" name="client_type"
                            class="w-full px-4 py-2.5 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-tailor-gold focus:border-transparent @error('client_type') border-red-300 focus:ring-red-500 @enderror">
                        <option value="">-- Pilih Tipe --</option>
                        @foreach($clientTypeOptions as $type)
                            <option value="{{ $type }}" {{ old('client_type') === $type ? 'selected' : '' }}>{{ $type }}</option>
                        @endforeach
                    </select>
                    @error('client_type')
                        <p class="text-xs text-red-500 mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="price_range" class="block text-sm font-medium text-slate-700 mb-1.5">
                        Kisaran Harga
                    </label>
                    <input type="text" id="price_range" name="price_range"
                           value="{{ old('price_range') }}"
                           placeholder="Contoh: Rp 250.000 - Rp 500.000"
                           class="w-full px-4 py-2.5 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-tailor-gold focus:border-transparent @error('price_range') border-red-300 focus:ring-red-500 @enderror">
                    @error('price_range')
                        <p class="text-xs text-red-500 mt-1">{{ $message }}</p>
                    @enderror
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label for="completed_at" class="block text-sm font-medium text-slate-700 mb-1.5">
                        Tanggal Selesai
                    </label>
                    <input type="date" id="completed_at" name="completed_at"
                           value="{{ old('completed_at') }}"
                           max="{{ now()->format('Y-m-d') }}"
                           class="w-full px-4 py-2.5 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-tailor-gold focus:border-transparent @error('completed_at') border-red-300 focus:ring-red-500 @enderror">
                    @error('completed_at')
                        <p class="text-xs text-red-500 mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <label class="flex items-center gap-3 rounded-xl border border-slate-200 px-4 py-3 bg-slate-50">
                    <input type="checkbox" name="is_featured" value="1"
                           class="rounded border-slate-300 text-tailor-purple focus:ring-tailor-gold"
                           {{ old('is_featured') ? 'checked' : '' }}>
                    <span>
                        <span class="block text-sm font-semibold text-slate-700">Jadikan karya unggulan</span>
                        <span class="block text-xs text-slate-500 mt-0.5">Ditampilkan lebih dulu di profil publik.</span>
                    </span>
                </label>
            </div>

            {{-- Description --}}
            <div>
                <label for="description" class="block text-sm font-medium text-slate-700 mb-1.5">
                    Deskripsi
                </label>
                <textarea id="description" name="description" rows="4"
                          placeholder="Ceritakan detail karya ini: bahan yang digunakan, teknik khusus, atau keunikannya..."
                          class="w-full px-4 py-2.5 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-tailor-gold focus:border-transparent resize-none @error('description') border-red-300 focus:ring-red-500 @enderror">{{ old('description') }}</textarea>
                @error('description')
                    <p class="text-xs text-red-500 mt-1">{{ $message }}</p>
                @enderror
            </div>

            {{-- Actions --}}
            <div class="flex flex-col-reverse gap-3 pt-2 border-t border-slate-100 sm:flex-row sm:items-center sm:justify-between">
                <a href="{{ route('tailor.portfolios.index') }}"
                   class="flex items-center justify-center gap-2 rounded-lg bg-slate-100 px-5 py-2.5 text-sm font-semibold text-slate-700 transition-colors hover:bg-slate-200">
                    <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                    </svg>
                    Kembali
                </a>
                <button type="submit"
                        class="brand-gradient flex items-center justify-center gap-2 rounded-lg px-6 py-2.5 text-sm font-semibold text-white shadow-sm transition-opacity hover:opacity-90">
                    <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/>
                    </svg>
                    Simpan Portfolio
                </button>
            </div>
        </form>
    </div>
</div>
@endsection

@push('scripts')
<script>
    const imageInput = document.getElementById('image');
    const preview = document.getElementById('image-preview');
    const previewContainer = document.getElementById('image-preview-container');
    const placeholder = document.getElementById('image-placeholder');

    function showPreview(file) {
        if (!file || !file.type.startsWith('image/')) return;
        const reader = new FileReader();
        reader.onload = (e) => {
            preview.src = e.target.result;
            previewContainer.classList.remove('hidden');
            placeholder.classList.add('hidden');
        };
        reader.readAsDataURL(file);
    }

    imageInput.addEventListener('change', (e) => {
        showPreview(e.target.files[0]);
    });

    function handleDragOver(e) {
        e.preventDefault();
        document.getElementById('image-dropzone').classList.add('border-tailor-purple', 'bg-tailor-soft/50');
    }

    function handleDragLeave(e) {
        document.getElementById('image-dropzone').classList.remove('border-tailor-purple', 'bg-tailor-soft/50');
    }

    function handleDrop(e) {
        e.preventDefault();
        document.getElementById('image-dropzone').classList.remove('border-tailor-purple', 'bg-tailor-soft/50');
        const file = e.dataTransfer.files[0];
        if (file) {
            // Transfer to input
            const dt = new DataTransfer();
            dt.items.add(file);
            imageInput.files = dt.files;
            showPreview(file);
        }
    }
</script>
@endpush
