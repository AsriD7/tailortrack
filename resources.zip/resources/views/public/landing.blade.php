@extends('layouts.customer')

@section('title', 'TailorTrack - Jasa Jahit Custom dengan Tracking Pesanan')

@section('content')
@php
    $categories = [
        ['name' => 'Kebaya', 'desc' => 'Busana formal, wisuda, dan acara keluarga.', 'icon' => 'M12 3l2.4 5.6 6.1.6-4.6 4 1.4 6-5.2-3.1L6 19.2l1.4-6-4.6-4 6.1-.6L12 3z'],
        ['name' => 'Jas', 'desc' => 'Setelan rapi untuk kerja, seminar, dan acara resmi.', 'icon' => 'M8 4h8l2 5v11H6V9l2-5zm4 0v16'],
        ['name' => 'Dress', 'desc' => 'Custom dress sesuai desain dan ukuran tubuh.', 'icon' => 'M12 3l4 5-2 13H10L8 8l4-5z'],
        ['name' => 'Seragam', 'desc' => 'Seragam komunitas, kantor, sekolah, dan organisasi.', 'icon' => 'M4 7l8-4 8 4v13H4V7zm4 4h8M8 15h8'],
        ['name' => 'Kemeja', 'desc' => 'Kemeja casual maupun formal dengan ukuran pas.', 'icon' => 'M7 4h10l3 4v12H4V8l3-4zm2 0l3 4 3-4'],
        ['name' => 'Permak', 'desc' => 'Perbaikan ukuran, resleting, dan penyesuaian pakaian.', 'icon' => 'M4 20l4-1 9-9-3-3-9 9-1 4zm11-15l4 4'],
    ];

    $features = [
        ['title' => 'Pesan Custom', 'desc' => 'Pelanggan mengirim detail ukuran, catatan, dan referensi desain dalam satu alur.', 'icon' => 'M12 4v16m8-8H4'],
        ['title' => 'Progress Jelas', 'desc' => 'Penjahit bisa update tahap pekerjaan, pelanggan bisa memantau dari dashboard.', 'icon' => 'M4 12h4l2 4 4-8 2 4h4'],
        ['title' => 'Pembayaran Rapi', 'desc' => 'Customer memilih full atau DP, lalu admin memverifikasi bukti transfer.', 'icon' => 'M4 7h16v10H4V7zm0 4h16'],
        ['title' => 'Portfolio Penjahit', 'desc' => 'Hasil karya penjahit tampil sebagai bahan pertimbangan sebelum order.', 'icon' => 'M4 16l4-4 3 3 5-6 4 5M4 6h16v12H4V6z'],
    ];
@endphp

<section class="bg-tailor-cream">
    <div class="mx-auto grid max-w-7xl gap-12 px-4 py-14 sm:px-6 lg:grid-cols-[1fr_0.92fr] lg:px-8 lg:py-20">
        <div class="flex flex-col justify-center">
            <span class="inline-flex w-fit items-center gap-2 rounded-full bg-white px-4 py-2 text-sm font-extrabold text-tailor-purple shadow-sm ring-1 ring-tailor-purple/10">
                <span class="h-2.5 w-2.5 rounded-full bg-tailor-gold"></span>
                Jasa jahit custom dengan tracking pesanan
            </span>

            <h1 class="mt-6 max-w-3xl text-4xl font-black leading-tight text-tailor-deep sm:text-5xl lg:text-6xl">
                Pesan jahitan custom, pantau prosesnya sampai selesai.
            </h1>

            <p class="mt-6 max-w-2xl text-base leading-8 text-slate-600 sm:text-lg">
                TailorTrack membantu pelanggan memilih penjahit, mengirim desain, memilih pembayaran full atau DP, dan melihat progress jahitan dari dashboard yang ramah mobile.
            </p>

            <div class="mt-8 flex flex-col gap-3 sm:flex-row">
                <a href="{{ route('tailors.index') }}" class="inline-flex items-center justify-center gap-2 rounded-2xl brand-gradient px-7 py-4 text-base font-extrabold text-white shadow-soft transition hover:-translate-y-0.5">
                    Cari Penjahit
                    <svg class="h-5 w-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
                    </svg>
                </a>
                <a href="{{ route('portfolios.index') }}" class="inline-flex items-center justify-center rounded-2xl border border-tailor-purple/15 bg-white px-7 py-4 text-base font-extrabold text-tailor-purple shadow-sm transition hover:border-tailor-gold/60 hover:bg-tailor-cream">
                    Lihat Portfolio
                </a>
            </div>

            <div class="mt-10 grid max-w-xl grid-cols-3 gap-3">
                <div class="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-tailor-purple/10">
                    <p class="text-2xl font-black text-tailor-purple">{{ number_format($stats['tailors'] ?? 0, 0, ',', '.') }}</p>
                    <p class="mt-1 text-xs font-bold text-slate-500">Penjahit</p>
                </div>
                <div class="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-tailor-purple/10">
                    <p class="text-2xl font-black text-tailor-purple">{{ number_format($stats['orders'] ?? 0, 0, ',', '.') }}</p>
                    <p class="mt-1 text-xs font-bold text-slate-500">Pesanan</p>
                </div>
                <div class="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-tailor-purple/10">
                    <p class="text-2xl font-black text-tailor-purple">{{ $stats['avg_rating'] ? number_format($stats['avg_rating'], 1) : '-' }}</p>
                    <p class="mt-1 text-xs font-bold text-slate-500">Rating</p>
                </div>
            </div>
        </div>

        <div class="lg:pt-6">
            <div class="rounded-[2rem] bg-white p-4 shadow-soft ring-1 ring-tailor-purple/10">
                <div class="rounded-[1.5rem] brand-gradient p-5 text-white sm:p-6">
                    <div class="flex items-start justify-between gap-5">
                        <div>
                            <p class="text-sm font-bold text-white/70">Preview Pesanan</p>
                            <h2 class="mt-2 text-2xl font-black">Dress Custom Premium</h2>
                            <p class="mt-3 max-w-md text-sm leading-6 text-white/75">
                                Referensi desain sudah diupload. Penjahit sedang mengerjakan pola dan potongan kain.
                            </p>
                        </div>
                        <div class="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-white/15">
                            <svg class="h-7 w-7" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M14.5 4.5l5 5M4 20l4.5-1 10-10-3.5-3.5-10 10L4 20z"/>
                            </svg>
                        </div>
                    </div>

                    <div class="mt-6 grid gap-3 sm:grid-cols-2">
                        <div class="rounded-2xl bg-white/12 p-4 ring-1 ring-white/10">
                            <p class="text-xs font-bold text-white/60">Penjahit</p>
                            <p class="mt-1 font-extrabold">Nara Tailor Studio</p>
                        </div>
                        <div class="rounded-2xl bg-white/12 p-4 ring-1 ring-white/10">
                            <p class="text-xs font-bold text-white/60">Estimasi</p>
                            <p class="mt-1 font-extrabold">5-7 Hari</p>
                        </div>
                    </div>

                    <div class="mt-6 rounded-3xl bg-white p-5 text-tailor-ink">
                        <div class="flex items-center justify-between gap-4">
                            <div>
                                <p class="text-xs font-bold uppercase tracking-[0.18em] text-slate-400">Progress</p>
                                <p class="mt-1 text-xl font-black text-tailor-deep">Sedang Diproses</p>
                            </div>
                            <span class="rounded-full bg-tailor-gold/20 px-3 py-1 text-xs font-black text-tailor-deep">75%</span>
                        </div>

                        <div class="mt-5 h-3 overflow-hidden rounded-full bg-tailor-soft">
                            <div class="h-full w-3/4 rounded-full gold-gradient"></div>
                        </div>

                        <div class="mt-5 grid grid-cols-4 gap-2 text-center text-[10px] font-bold text-slate-400">
                            <span>Order</span>
                            <span>Bayar</span>
                            <span>Jahit</span>
                            <span>Selesai</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mt-4 rounded-3xl bg-white p-5 shadow-sm ring-1 ring-tailor-purple/10">
                <div class="flex items-center gap-3">
                    <div class="grid h-12 w-12 place-items-center rounded-2xl bg-tailor-soft text-tailor-purple">
                        <svg class="h-6 w-6" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                        </svg>
                    </div>
                    <div>
                        <p class="font-black text-tailor-deep">{{ $stats['avg_rating'] ? number_format($stats['avg_rating'], 1) . '/5 Rating' : 'Belum ada rating' }}</p>
                        <p class="text-xs font-semibold text-slate-500">{{ ($stats['review_count'] ?? 0) > 0 ? 'Dari ' . number_format($stats['review_count'], 0, ',', '.') . ' ulasan pelanggan' : 'Menunggu ulasan pelanggan' }}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="bg-white py-16">
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div class="mx-auto max-w-2xl text-center">
            <span class="rounded-full bg-tailor-soft px-4 py-2 text-sm font-extrabold text-tailor-purple">Fitur Utama</span>
            <h2 class="mt-5 text-3xl font-black text-tailor-deep sm:text-4xl">Alur jahit dibuat jelas untuk customer dan penjahit.</h2>
        </div>

        <div class="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            @foreach($features as $feature)
                <div class="rounded-3xl border border-tailor-purple/10 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-soft">
                    <div class="grid h-14 w-14 place-items-center rounded-2xl bg-tailor-soft p-3 text-tailor-purple">
                        <svg class="h-7 w-7" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="{{ $feature['icon'] }}"/>
                        </svg>
                    </div>
                    <h3 class="mt-5 text-lg font-black text-tailor-deep">{{ $feature['title'] }}</h3>
                    <p class="mt-3 text-sm leading-7 text-slate-500">{{ $feature['desc'] }}</p>
                </div>
            @endforeach
        </div>
    </div>
</section>

<section class="bg-tailor-cream py-16">
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div class="flex flex-col justify-between gap-5 md:flex-row md:items-end">
            <div>
                <span class="rounded-full bg-white px-4 py-2 text-sm font-extrabold text-tailor-purple shadow-sm">Kategori Jahitan</span>
                <h2 class="mt-5 text-3xl font-black text-tailor-deep sm:text-4xl">Pilih jenis jahitan sesuai kebutuhanmu.</h2>
            </div>
            <a href="{{ route('price-lists.index') }}" class="inline-flex items-center gap-2 font-extrabold text-tailor-purple hover:text-tailor-deep">
                Lihat daftar harga
                <svg class="h-4 w-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
                </svg>
            </a>
        </div>

        <div class="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            @foreach($categories as $category)
                <a href="{{ route('price-lists.index') }}" class="group rounded-3xl border border-tailor-purple/10 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-soft">
                    <div class="grid h-14 w-14 place-items-center rounded-2xl brand-gradient text-white shadow-soft">
                        <svg class="h-7 w-7" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="{{ $category['icon'] }}"/>
                        </svg>
                    </div>
                    <h3 class="mt-6 text-xl font-black text-tailor-deep">{{ $category['name'] }}</h3>
                    <p class="mt-2 text-sm leading-7 text-slate-500">{{ $category['desc'] }}</p>
                </a>
            @endforeach
        </div>
    </div>
</section>

<section class="bg-white py-16">
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div class="flex flex-col justify-between gap-5 md:flex-row md:items-end">
            <div>
                <span class="rounded-full bg-tailor-soft px-4 py-2 text-sm font-extrabold text-tailor-purple">Penjahit Unggulan</span>
                <h2 class="mt-5 text-3xl font-black text-tailor-deep sm:text-4xl">Temukan penjahit yang sesuai dengan gayamu.</h2>
            </div>
            <a href="{{ route('tailors.index') }}" class="inline-flex items-center gap-2 font-extrabold text-tailor-purple hover:text-tailor-deep">
                Lihat semua penjahit
                <svg class="h-4 w-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
                </svg>
            </a>
        </div>

        @if($tailors->isNotEmpty())
            <div class="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                @foreach($tailors as $tailor)
                    @php
                        $profile = $tailor->tailorProfile;
                        $shopName = $profile->shop_name ?? $tailor->name ?? 'TailorTrack';
                        $avgRating = round((float) ($tailor->reviews_received_avg_rating ?? 0), 1);
                        $reviewCount = (int) ($tailor->reviews_received_count ?? 0);
                    @endphp
                    <a href="{{ route('tailors.show', $tailor) }}" class="overflow-hidden rounded-3xl border border-tailor-purple/10 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-soft">
                        <div class="h-2 gold-gradient"></div>
                        <div class="p-6">
                            <div class="flex items-start gap-4">
                                @if($profile && $profile->photo)
                                    <img src="{{ Storage::url($profile->photo) }}" alt="{{ $shopName }}" class="h-16 w-16 rounded-2xl object-cover ring-4 ring-tailor-soft">
                                @else
                                    <div class="grid h-16 w-16 place-items-center rounded-2xl brand-gradient text-2xl font-black text-white ring-4 ring-tailor-soft">{{ strtoupper(substr($shopName, 0, 1)) }}</div>
                                @endif
                                <div class="min-w-0 flex-1">
                                    <h3 class="truncate text-lg font-black text-tailor-deep">{{ $shopName }}</h3>
                                    <p class="mt-1 text-sm font-semibold text-slate-500">{{ $profile->specialization ?? 'Jasa Jahit Custom' }}</p>
                                    @if($reviewCount > 0)
                                        <p class="mt-2 text-xs font-bold text-tailor-purple">Rating {{ number_format($avgRating, 1) }} dari {{ $reviewCount }} ulasan</p>
                                    @else
                                        <p class="mt-2 text-xs font-bold text-slate-400">Belum ada ulasan</p>
                                    @endif
                                </div>
                            </div>
                            <p class="mt-5 line-clamp-2 text-sm leading-7 text-slate-500">{{ $profile->description ?? 'Siap membantu membuat pakaian custom sesuai kebutuhan pelanggan.' }}</p>
                        </div>
                    </a>
                @endforeach
            </div>
        @else
            <div class="mt-10 rounded-3xl border border-dashed border-tailor-purple/20 bg-tailor-cream p-10 text-center">
                <p class="font-extrabold text-tailor-deep">Belum ada penjahit unggulan.</p>
                <p class="mt-2 text-sm text-slate-500">Data penjahit akan muncul setelah profil tersedia.</p>
            </div>
        @endif
    </div>
</section>

<section class="bg-tailor-cream py-16">
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div class="flex flex-col justify-between gap-5 md:flex-row md:items-end">
            <div>
                <span class="rounded-full bg-white px-4 py-2 text-sm font-extrabold text-tailor-purple shadow-sm">Portfolio Terbaru</span>
                <h2 class="mt-5 text-3xl font-black text-tailor-deep sm:text-4xl">Lihat hasil jahitan sebelum menentukan pilihan.</h2>
            </div>
            <a href="{{ route('portfolios.index') }}" class="inline-flex items-center gap-2 font-extrabold text-tailor-purple hover:text-tailor-deep">
                Lihat semua portfolio
                <svg class="h-4 w-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
                </svg>
            </a>
        </div>

        @if($portfolios->isNotEmpty())
            <div class="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                @foreach($portfolios as $portfolio)
                    <a href="{{ route('portfolios.show', $portfolio) }}" class="group overflow-hidden rounded-3xl border border-tailor-purple/10 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-soft">
                        <div class="aspect-[4/3] overflow-hidden bg-tailor-soft">
                            @if($portfolio->image)
                                <img src="{{ Storage::url($portfolio->image) }}" alt="{{ $portfolio->title }}" class="h-full w-full object-cover transition duration-500 group-hover:scale-105">
                            @else
                                <div class="grid h-full w-full place-items-center text-tailor-purple/40">
                                    <svg class="h-16 w-16" fill="none" stroke="currentColor" stroke-width="1.6" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M4 16l4-4 3 3 5-6 4 5M4 6h16v12H4V6z"/>
                                    </svg>
                                </div>
                            @endif
                        </div>
                        <div class="p-6">
                            <p class="text-xs font-black uppercase tracking-[0.18em] text-tailor-gold">Portfolio</p>
                            <h3 class="mt-2 line-clamp-1 text-lg font-black text-tailor-deep">{{ $portfolio->title }}</h3>
                            <p class="mt-2 text-sm font-semibold text-slate-500">{{ $portfolio->tailor->tailorProfile->shop_name ?? $portfolio->tailor->name ?? 'Penjahit TailorTrack' }}</p>
                        </div>
                    </a>
                @endforeach
            </div>
        @else
            <div class="mt-10 rounded-3xl border border-dashed border-tailor-purple/20 bg-white p-10 text-center">
                <p class="font-extrabold text-tailor-deep">Belum ada portfolio terbaru.</p>
                <p class="mt-2 text-sm text-slate-500">Portfolio akan tampil setelah penjahit mengunggah hasil karya.</p>
            </div>
        @endif
    </div>
</section>

<section class="bg-white py-16">
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div class="rounded-[2rem] brand-gradient p-8 text-white shadow-soft md:p-12">
            <div class="grid gap-10 lg:grid-cols-[1fr_0.88fr] lg:items-center">
                <div>
                    <span class="rounded-full bg-white/15 px-4 py-2 text-sm font-extrabold ring-1 ring-white/20">Alur TailorTrack</span>
                    <h2 class="mt-6 text-3xl font-black sm:text-4xl">Dari desain sampai pakaian selesai, semua tahap punya catatan.</h2>
                    <div class="mt-8 flex flex-col gap-3 sm:flex-row">
                        <a href="{{ route('tailors.index') }}" class="rounded-2xl bg-white px-6 py-3.5 text-center font-extrabold text-tailor-purple">Mulai Cari Penjahit</a>
                        <a href="{{ route('price-lists.index') }}" class="rounded-2xl border border-white/30 px-6 py-3.5 text-center font-extrabold text-white hover:bg-white/10">Cek Harga</a>
                    </div>
                </div>
                <div class="rounded-3xl bg-white p-5 text-tailor-ink">
                    <div class="space-y-4">
                        @foreach(['Pilih penjahit', 'Kirim desain dan ukuran', 'Konfirmasi harga', 'Upload pembayaran', 'Pantau progress', 'Pesanan selesai'] as $index => $step)
                            <div class="flex items-center gap-4">
                                <div class="grid h-10 w-10 shrink-0 place-items-center rounded-full {{ $index < 5 ? 'bg-tailor-purple text-white' : 'bg-tailor-gold text-tailor-deep' }} text-sm font-black">{{ $index + 1 }}</div>
                                <div class="h-1 flex-1 rounded-full {{ $index < 5 ? 'bg-tailor-soft' : 'bg-tailor-gold/40' }}"></div>
                                <p class="w-36 text-sm font-extrabold text-tailor-deep">{{ $step }}</p>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
